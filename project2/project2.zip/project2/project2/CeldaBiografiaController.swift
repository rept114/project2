

import Foundation
import UIKit
class CeldaBiografiaController: UITableViewCell {
    
    @IBOutlet weak var lblDbiografia: UILabel!
    
    
}
