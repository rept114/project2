//
//  View.swift
//  project2
//
//  Created by Alumno on 10/3/22.
//  Copyright © 2022 Alumno. All rights reserved.
//

import Foundation

class Presidente {
    var nombre: String
    var sexenio: String
    var edad: String
    var descripcion: String
    var fotito: String
    init(nombre:String, sexenio:String, edad:String, descripcion: String, fotito: String) {
        self.nombre = nombre
        self.sexenio = sexenio
        self.edad = edad
        self.descripcion = descripcion
        self.fotito = fotito
    }
}
