//
//  Pelicula.swift
//  prototipo
//
//  Created by Alumno on 9/23/22.
//  Copyright © 2022 Alumno. All rights reserved.
//

import Foundation

class Biografia {
    var Biografia: String
    init(Biografia: String) {
        self.Biografia = Biografia
    }
}
