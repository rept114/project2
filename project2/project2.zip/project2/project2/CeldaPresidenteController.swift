//
//  CeldaPresidenteController.swift
//  project2
//
//  Created by Alumno on 10/5/22.
//  Copyright © 2022 Alumno. All rights reserved.
//

import Foundation
import UIKit
class CeldaPresidenteController: UITableViewCell {
 
    @IBOutlet weak var lblImage: UIImageView!
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var lblEdad: UILabel!
    @IBOutlet weak var lblSexenio: UILabel!
    
}
