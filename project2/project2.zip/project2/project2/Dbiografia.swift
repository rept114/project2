//
//  Dbiografia.swift
//  project2
//
//  Created by Alumno on 10/17/22.
//  Copyright © 2022 Alumno. All rights reserved.
//

import Foundation

class Dbiografia {
    var puestos: String
    init(puestos: String) {
        self.puestos = puestos
    }
}
